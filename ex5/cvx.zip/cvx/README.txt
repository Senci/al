CVX: A system for disciplined convex programming
Copyright 2012 CVX Research, Inc.
--------------------------------------------------------

Thank you for downloading cvx. Please see the Installation chapter of the
users' guide, found here as cvx_usrguide.pdf, or online at the location
http://cvxr.com/cvx/doc, for information on how to install and use this
software.

Files of interest:
    LICENSE.txt, GPL.txt: license information
    cvx_usrguide.pdf:     documentation
    examples/:            usage examples
    cvx_setup.m:          installation script
